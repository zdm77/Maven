create function ins_role_access()
  returns trigger
language plpgsql
as $$
BEGIN
insert into  "пользователи"."доступ" ("код_роли") values(NEW.id);
RETURN NEW;
END;
$$;

