create view "пользователь_роль" as
  SELECT u.id,
    u.name AS "фио",
    u."пароль",
    u."код_роли",
    r.name AS "роль",
    u.login
   FROM ("пользователи"."пользователи" u
     JOIN "пользователи"."роли" r ON ((u."код_роли" = r.id)));

