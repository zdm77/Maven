create function except_del()
  returns character varying
language plpgsql
as $$
DECLARE
  message varchar(500);
BEGIN
 message='Есть связаные значения. Удаление запрещено.';
RETURN message;
END;
$$;

