create function "upd_awb_вес_стоимость"()
  returns trigger
language plpgsql
as $$
declare v numeric(15,2);
  declare s numeric(15,2);
BEGIN
  select sum(вес)
  from "бух".sub_awb
  where "код_AWB" = new . "код_AWB"
  into v;
  select sum(стоимость)
  from "бух".sub_awb
  where "код_AWB" = new . "код_AWB"
  into s;
  update "бух".awb
  set вес = v,
      стоимость = s
  where id = new . "код_AWB";
  RETURN NEW;
END;
$$;

