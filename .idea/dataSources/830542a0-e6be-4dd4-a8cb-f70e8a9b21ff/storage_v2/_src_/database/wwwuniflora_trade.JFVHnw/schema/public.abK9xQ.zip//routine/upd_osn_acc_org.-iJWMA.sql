create function upd_osn_acc_org()
  returns trigger
language plpgsql
as $$
BEGIN
UPDATE "организация"."счета_рус" set основной=FALSE where  "код_организации"=new.код_организации
and id<>old.id;
END;
$$;

