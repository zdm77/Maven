create function "итог_баланс_плантаций"(i_arch integer DEFAULT 0, i_date date DEFAULT now())
  returns TABLE("о_name" character varying, "о_id" integer, "о_fb" numeric, "о_box" numeric, "о_fb_fact" numeric, "о_box_fact" numeric, "о_сумма_фактур" numeric, "о_сумма_оплат" numeric, "о_претензии" numeric, "о_разница" numeric)
language plpgsql
as $$
DECLARE
  rec RECORD;
  var ALIAS FOR $1;
  prit numeric;

BEGIN
  FOR о_id, о_name    IN
  SELECT DISTINCT код_плантации,
         pl.name
  from "бух".awb aw
       INNER JOIN "бух".sub_awb ON (aw.id = "бух".sub_awb."код_AWB")
       INNER JOIN "бух".sub_awb_detail a ON ("бух".sub_awb.id =
      a."код_sub_awb")
       inner join "продукция"."плантации" pl on (a."код_плантации" = pl.id)
      where aw."архив_awb" = i_arch 
  order by pl.name
  LOOP
    select *
    from "бух"."сумма_претензий"(о_id, i_arch)
    into о_претензии;
    select sum(COALESCE("сумма_фактуры", 0)),
           sum(a1."кол_во_fb"),
           sum(a1."кол_во"),
           sum(a1."FB_фактура"),
           sum(a1."BOX_фактура")
    from "бух".sub_awb_detail a1
    inner join "бух".sub_awb sa on (sa.id=a1."код_sub_awb")
    inner join "бух".awb aw on (aw.id=sa."код_AWB") 
    where код_плантации = о_id and aw."архив_awb"=i_arch and a1."дата_фактуры"<= i_date
    into о_сумма_фактур,
         о_fb,
         о_box,
         о_fb_fact,
         о_box_fact;
    select sum(COALESCE(o."сумма_пп", 0))
    from "бух"."бух_оплата_плантации" o
    where код_плантации = о_id and архив_опл=i_arch and o."дата_пп"<=i_date
    into о_сумма_оплат;
    о_разница = COALESCE(о_сумма_фактур,0)-COALESCE(о_сумма_оплат,0)-COALESCE(
    о_претензии,0);
    RETURN next;
  END LOOP;

END;
$$;

