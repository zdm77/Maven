create function upd_oplata_awb()
  returns trigger
language plpgsql
as $$
declare v numeric(15,2);
  
BEGIN
   select sum("сумма")
  from "бух"."оплата_awb" 
  where "код_awb" = new."код_awb"
  into v;
   update "бух".awb 
  set "сумма_оплат" = v
  where id = new."код_awb";
  RETURN NEW;
END;
$$;

