create function "обновить_изменения"()
  returns trigger
language plpgsql
as $$
BEGIN
 UPDATE "бд"."изменения"
  SET "изменен" = now()
  WHERE таблица = 'маркировки';
   RETURN NEW;
END;
$$;

