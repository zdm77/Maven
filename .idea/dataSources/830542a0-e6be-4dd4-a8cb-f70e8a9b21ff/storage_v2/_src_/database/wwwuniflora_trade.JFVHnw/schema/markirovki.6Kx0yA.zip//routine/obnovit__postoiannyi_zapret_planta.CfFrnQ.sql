create function "обновить_постоянный_запрет_планта"()
  returns trigger
language plpgsql
as $$
BEGIN
 UPDATE "бд"."изменения"
  SET "изменен" = now()
  WHERE таблица = 'постоянный_запрет_плантаций';
   RETURN NEW;
END;
$$;

