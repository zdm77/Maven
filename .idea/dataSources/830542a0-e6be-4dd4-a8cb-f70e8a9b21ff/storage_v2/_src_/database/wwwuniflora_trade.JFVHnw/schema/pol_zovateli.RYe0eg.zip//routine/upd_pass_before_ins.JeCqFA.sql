create function upd_pass_before_ins()
  returns trigger
language plpgsql
as $$
BEGIN

NEW.пароль=md5(new.пароль);

RETURN NEW;
END;
$$;

