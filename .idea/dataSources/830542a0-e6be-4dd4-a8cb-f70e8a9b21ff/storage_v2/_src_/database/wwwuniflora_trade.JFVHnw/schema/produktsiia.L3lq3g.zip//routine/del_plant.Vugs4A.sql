create function del_plant()
  returns trigger
language plpgsql
as $$
BEGIN
delete from "продукция"."продукция" p where p."код_детализации"=old.id and p."код_структуры"=4;
RETURN OLD;
END;
$$;

