create function ins_zakup(id_ins boolean, "s_код_детали_заказа" integer, "s_код_пользователя" integer, "s_дата_закупки" date, "s_код_плантации" integer, "s_код_маркировки" integer, "s_дата_вылета" date, s_id integer, OUT new_id integer, OUT o_id_factura integer, s_id_zakaz integer)
  returns record
language plpgsql
as $$
BEGIN
  if (id_ins=true)
    then
    select nextval('"документы"."закупки_id_seq"')
    into new_id;
    INSERT INTO "документы"."закупки"(id, "код_детали_заказа",
     "код_пользователя", дата_закупки, дата_вылета_edt, код_заказа)
    VALUES (new_id, s_код_детали_заказа, s_код_пользователя, s_дата_закупки,
     s_дата_вылета, s_id_zakaz);
    update "документы"."заказы_деталь"
    set код_закупки = new_id
    where id = s_код_детали_заказа;

    /*фактуры*/
    select id
    from "документы"."фактуры" f
    into o_id_factura
    where f."дата_закупки" = s_дата_закупки and
          f."код_маркировки" = s_код_маркировки and
          f."код_плантации" = s_код_плантации;
    if o_id_factura is null then
      select nextval('"документы"."фактуры_id_seq"')
      into o_id_factura;
      INSERT INTO "документы"."фактуры"(id, "код_пользователя", "код_статуса",
       "дата_вылета", "код_маркировки", "код_плантации", дата_фактуры,
        дата_закупки)
      VALUES (o_id_factura, s_код_пользователя, 1, s_дата_вылета,
       s_код_маркировки, s_код_плантации, s_дата_закупки, s_дата_закупки);

    end if;
    update "документы"."закупки"
    set код_фактуры = o_id_factura
    where id = new_id;
    else
    update "документы"."закупки"
    set id = s_id
    where id = s_id;
  end if;

  /* return new_id;*/
END;
$$;

