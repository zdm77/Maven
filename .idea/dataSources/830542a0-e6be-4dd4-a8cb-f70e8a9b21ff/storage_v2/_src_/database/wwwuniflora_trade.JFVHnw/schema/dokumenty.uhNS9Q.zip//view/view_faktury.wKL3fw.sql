create view "view_фактуры" as
  SELECT fd."код_фактуры",
    s1.id AS s_id,
    fd.id AS id_fd,
    p.uni_name AS p_uni_name,
    p.reg_name AS p_reg_name,
    p.name AS p_name,
    fd.fb AS fb_fact,
    fd."стеблей" AS st_fact,
    fd."длина" AS dl_fact,
    fd."цена" AS price_fact,
    fd."код_плантации",
    p.id AS p_id,
    p.brand,
    p."код_страны",
    p."примечание",
    zd."цена" AS price_zakup,
    zd.fb AS fb_zakup,
    zd."длина" AS dl_zakup,
    zd."стеблей" AS steb_zakup,
    s1.name AS sort_fact,
    s.name AS sort_zakup,
    pr.id AS pr_id_zakup,
    pr.name AS pr_name_zakup,
    pr.uni_name AS pr_uni_name_zakup,
    pr.reg_name AS pr_reg_name_zakup,
    pr1.id AS pr_id_fact,
    pr1.name AS pr_name_fact,
    pr1.uni_name AS pr_uni_name_fact,
    pr1.reg_name AS pr_reg_name_fact,
    ((fd."стеблей")::numeric * fd."цена") AS itog_fact,
    ((zd."стеблей")::numeric * zd."цена") AS itog_zakup,
    (((zd."стеблей")::numeric * zd."цена") - ((fd."стеблей")::numeric * fd."цена")) AS "Разница",
    zd."код_деталь_заказ" AS id_zd,
    fd."код_закупки",
    t.uni_name AS t_uni_name,
    t.name AS t_name,
    t.reg_name AS t_reg_name,
    t1.name AS t1_name,
    t1.uni_name AS t1_unui_name,
    t1.reg_name AS t1_reg_name,
    m.name AS m_name,
    m.uni_name AS m_uni_name,
    m.reg_name AS m_reg_name,
    o.name AS o_name
   FROM (((((((((("документы"."фактура_деталь" fd
     JOIN "продукция"."плантации" p ON ((fd."код_плантации" = p.id)))
     JOIN "документы"."закупки_деталь" zd ON (((fd."код_детализ_закупки" = zd.id) AND (p.id = zd."код_плантации"))))
     JOIN "продукция"."сорта" s ON ((zd."код_сорта" = s.id)))
     JOIN "продукция"."сорта" s1 ON ((fd."код_сорта" = s1.id)))
     JOIN "продукция"."продукция" pr ON ((zd."код_товара" = pr.id)))
     JOIN "продукция"."продукция" pr1 ON ((fd."код_товара" = pr1.id)))
     JOIN "продукция"."типы" t ON ((pr."код_типа" = t.id)))
     JOIN "продукция"."типы" t1 ON ((pr1."код_типа" = t1.id)))
     JOIN "документы"."фактуры" f ON ((fd."код_фактуры" = f.id)))
     JOIN "маркировки"."маркировки" m ON ((f."код_маркировки" = m.id))),
    ( SELECT "организации".id,
            "организации".name,
            "организации"."полное_имя_оргнаизации",
            "организации"."в_лице",
            "организации"."инн",
            "организации"."имя_в_договоре",
            "организации"."гос_регистрация",
            "организации"."дата_гос_регистрации",
            "организации"."огрн",
            "организации"."подпись",
            "организации"."адрес_регистрации",
            "организации"."фактическй_адрес",
            "организации"."почтоввый_адрес",
            "организации"."телефон1",
            "организации"."телефон2",
            "организации"."телефон3",
            "организации"."почта",
            "организации"."факс",
            "организации"."сайт",
            "организации"."в_инвойсе",
            "организации"."окато",
            "организации"."окпо",
            "организации"."код_страны",
            "организации"."код_региона",
            "организации"."код_города"
           FROM "организация"."организации"
          WHERE ("организации"."в_инвойсе" = true)) o
  ORDER BY fd.id;

