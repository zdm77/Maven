create function get_product_plant(s_id_product integer, OUT o_tree character varying)
  returns character varying
language plpgsql
as $$
DECLARE
  i_pid integer;
  id_sort integer;
  id_plant integer;
  id_type integer;
BEGIN
  /*сорт*/
  select pid
  from "продукция"."продукция"
  into i_pid
  where id = s_id_product;
  select код_детализации
  from "продукция"."продукция"
  into id_sort
  where id = i_pid;
  select pid
  from "продукция"."продукция"
  into i_pid
  where id = i_pid;
  select код_детализации
  from "продукция"."продукция"
  into id_plant
  where id = i_pid;
  select pid
  from "продукция"."продукция"
  into i_pid
  where id = i_pid;
  select код_детализации
  from "продукция"."продукция"
  into id_type
  where id = i_pid;
  update "продукция"."продукция"
  set код_типа = id_type,
      код_плантации = id_plant,
      код_сорта = id_sort
  where id = s_id_product;
END;
$$;

