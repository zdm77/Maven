create function "оплата_плантаций"(i_id_plant integer, i_arch integer DEFAULT 0)
  returns TABLE("о_итог" numeric, "о_номер_awb" character varying, "о_дата_вылета" date, "о_код_awb" integer, "о_код" integer, "о_код_маркировки" integer, "о_вес" numeric, "о_стоимость" numeric, "о_код_трака" integer, "о_дата" date, "о_дата_фактуры" date, "о_дата_оплаты" date, "о_номер_фактуры" character varying, "о_номер_пп" character varying, "о_сумма_оплаты" numeric, "о_сумма_фактуры" numeric, "о_fb_фактура" numeric, "о_box_фактура" numeric, "о_маркировка" character varying, "о_трак" character varying, "о_кол_во_fb" numeric, "о_кол_во" numeric, "о_дата_притензии" date, "о_сумма_притензии" numeric, "о_одобренная_сумма_притензии" numeric, "о_статус_притензии" character varying, "о_текст_притензии_рус" text, "о_текст_притензии_исп" text, "о_текст_одобренной_суммы" text, "о_sa_id" integer)
language plpgsql
as $$
DECLARE
  rec RECORD;
  var ALIAS FOR $1;
  cur_test CURSOR FOR
    select a."номер_awb",
           a."дата_вылета",
           a.id id_awb,
           sad.id,
           sa.id sa_id,
           sa."код_маркировки",
           a."вес",
           a."стоимость",
           t.id t_id,
           дата_фактуры дата,
           sad."дата_фактуры",
           null дата_оплаты,
           sad."номер_фактуры",
           null номер_пп,
           null сумма_оплаты,
           sad."сумма_фактуры",
           sad."FB_фактура",
           sad."BOX_фактура",
           m.name,
           t.name трак,
           sad."кол_во_fb",
           sad."кол_во",
           sad."дата_притензии",
           sad."сумма_притензии",
           sad."одобренная_сумма_притензии",
           sad."статус_притензии",
           sad."текст_притензии_рус",
           sad."текст_притензии_исп",
           sad."текст_одобренной_суммы"
           
    FROM "бух".sub_awb_detail sad
         INNER JOIN "бух".sub_awb sa ON (sad."код_sub_awb" = sa.id)
         INNER JOIN "бух".awb a ON (sa."код_AWB" = a.id)
         INNER JOIN "маркировки"."маркировки" m ON (sa."код_маркировки" = m.id)
         inner join "траки"."траки" t on (sa."код_трака" = t.id)
    where "код_плантации" = $1 and a."архив_awb"=i_arch
    union all
    SELECT NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           opl."дата_пп" дата,
           null,
           opl."дата_пп",
           NULL,
           opl."номер_пп",
           opl."сумма_пп",
           null,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL
           
    FROM "бух"."бух_оплата_плантации" opl
    
    where "код_плантации" = $1 and opl."архив_опл"=i_arch
    order by дата;
BEGIN
  о_итог=0;
  FOR rec IN cur_test
  LOOP
    о_номер_awb=rec.номер_awb  ;
    о_дата_вылета =rec.дата_вылета ;
    о_код_awb= rec.id_awb;

    о_код=rec.id;
    о_sa_id=rec.sa_id;
    о_код_маркировки= rec.код_маркировки;
    о_вес = rec.вес;
    о_стоимость= rec.стоимость;
    о_код_трака= rec.t_id;
    о_дата=   rec.дата;
    о_дата_фактуры=    rec."дата_фактуры";
    о_дата_оплаты= rec.дата_оплаты;
    о_номер_фактуры=  rec."номер_фактуры";
    о_номер_пп= rec.номер_пп;
    о_сумма_оплаты= rec.сумма_оплаты;
    о_сумма_фактуры=  rec."сумма_фактуры";
    о_fb_фактура=  rec."FB_фактура";
    о_box_фактура=    rec."BOX_фактура";
    о_маркировка=   rec.name;
    о_трак= rec.трак;
    о_кол_во_fb=   rec."кол_во_fb";
    о_кол_во =    rec."кол_во";
    о_дата_притензии=   rec."дата_притензии";
    о_сумма_притензии= rec."сумма_притензии";
    о_одобренная_сумма_притензии= rec."одобренная_сумма_притензии";
    о_статус_притензии=  rec."статус_притензии";
    о_текст_притензии_рус= rec."текст_притензии_рус";
    о_текст_притензии_исп= rec."текст_притензии_исп";
    о_текст_одобренной_суммы= rec."текст_одобренной_суммы"  ;
    if rec."статус_притензии" = 'ok' THEN
      о_итог=COALESCE(о_итог,0)+COALESCE( rec.сумма_фактуры,0) -  COALESCE(
        rec.одобренная_сумма_притензии,0)  -  COALESCE(rec.сумма_оплаты,0);
      else
      о_итог=COALESCE(о_итог,0)+COALESCE( rec.сумма_фактуры,0) -  COALESCE(
        rec.сумма_притензии,0)  -  COALESCE(rec.сумма_оплаты,0);
    end if;

    RETURN next;
  END LOOP;

END;
$$;

