create function "удалить_продукцию"()
  returns integer
language plpgsql
as $$
DECLARE
 i integer;
BEGIN
delete from "продукция"."тип_страна";
SELECT setval('продукция.тип_страна_id_seq',1) into i;
delete from "продукция"."плантация_тип";
SELECT setval('продукция.плантация_тип_id_seq',1) into i;
delete from "продукция"."продукт_свойство";
SELECT setval('продукция.продукт_свойство_id_seq',1) into i;
delete from "продукция"."свойства_значения";
SELECT setval('продукция.свойства_значения_id_seq',1) into i;
delete from "продукция"."свойства";
SELECT setval('продукция.свойства_id_seq',1) into i;
DELETE from "продукция"."продукция" where pid not in (0,1);
SELECT setval('продукция.продукция_id_seq',(select max(id) from "продукция"."продукция")) into i;
delete from "продукция"."типы_свойства";
SELECT setval('продукция.типы_свойства_id_seq',1) into i;
delete from "продукция"."сорт_плантация";
SELECT setval('продукция.сорт_плантация_id_seq',1) into i;
delete from "продукция"."сорт_страна";
SELECT setval('продукция.сорт_страна_id_sec',1) into i;
delete from "продукция"."сорта";
SELECT setval('продукция.сорта_id_seq',1) into i;
return i;
END;
$$;

