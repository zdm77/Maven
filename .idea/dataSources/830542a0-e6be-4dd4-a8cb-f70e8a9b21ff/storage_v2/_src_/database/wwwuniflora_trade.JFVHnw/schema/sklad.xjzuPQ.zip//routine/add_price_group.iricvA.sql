create function add_price_group()
  returns trigger
language plpgsql
as $$
DECLARE
  id_length integer;
  id_unit integer;
  ord integer;
BEGIN
  FOR id_unit IN
  select id
  from "склад"."цеха"
  LOOP
    for id_length in
    select id
    from "склад"."длины"
    LOOP
      insert into "склад"."длина_цена"(код_длины, код_цены, код_цеха)
      values (id_length, new . id, id_unit);
    END LOOP;
  END LOOP;
  select max(сортировка)
  from "склад"."ценовые_группы"
  into ord;
  update "склад"."ценовые_группы"
  set сортировка = ord+1
  where id = new . id;
  return NEW;
END;
$$;

