create function upd_no_compras()
  returns trigger
language plpgsql
as $$
DECLARE
  fb_zakup numeric(15,2);
  fb_zakaz numeric(15,2);
  id_zakup integer;
BEGIN
  /*первый айдишник детали закупки*/
  select min(id)
  from "документы"."закупки_деталь"
  into id_zakup
  where код_заказа = new . код_заказа;
  /*сумма фулбоксов детали заказа*/
  select sum(od."кол_во_фулбоксов")
  from "документы"."заказы_деталь" od
  into fb_zakaz
  where od."код_заказа" = new . код_заказа;
  /*сумма фулбоксов датли закупки*/
  select sum(fb)
  from "документы"."закупки_деталь" zd
  into fb_zakup
  where zd."код_заказа" = new . код_заказа;
  /*обновляем недозакупку*/
  update "документы"."закупки_деталь"
  set no_compras =fb_zakaz - COALESCE( fb_zakup,0)  where id = id_zakup;
 
  RETURN new;
END;
$$;

