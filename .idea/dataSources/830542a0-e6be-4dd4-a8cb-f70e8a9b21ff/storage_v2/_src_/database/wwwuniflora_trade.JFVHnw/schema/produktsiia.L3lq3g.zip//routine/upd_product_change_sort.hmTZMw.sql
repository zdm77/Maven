create function upd_product_change_sort()
  returns trigger
language plpgsql
as $$
BEGIN
 update "продукция"."продукция" set name=new.name, uni_name=new.uni_name, reg_name=new.reg_name where 
       код_детализации=old.id and код_структуры=5;
 RETURN NEW;
END;
$$;

