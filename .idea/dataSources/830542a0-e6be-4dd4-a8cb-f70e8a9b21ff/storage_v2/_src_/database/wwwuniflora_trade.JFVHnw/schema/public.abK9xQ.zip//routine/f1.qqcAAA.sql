create function f1()
  returns trigger
language plpgsql
as $$
DECLARE
  s integer;
BEGIN
  s=5;
  
END;
$$;

