create function del_sort()
  returns trigger
language plpgsql
as $$
BEGIN
/*delete from "продукция"."продукция"  where pid in(select id from "продукция"."продукция" where "код_детализации"=old.id and "код_структуры"=5) ;*/
/*delete from "продукция"."продукция"  where "код_детализации"=old.id and "код_структуры"=5;*/


RETURN OLD;
END;
$$;

