create function add_price_length()
  returns trigger
language plpgsql
as $$
DECLARE
  id_type integer;
  id_unit integer;
BEGIN
  FOR id_unit IN
  select id
  from "склад"."цеха"
  LOOP
    for id_type in
    select id
    from "склад"."ценовые_группы"
    LOOP
      insert into "склад"."длина_цена"(код_длины, код_цены, код_цеха)
      values (new . id, id_type, id_unit);
    END LOOP;
  END LOOP;
  return NEW;
END;
$$;

