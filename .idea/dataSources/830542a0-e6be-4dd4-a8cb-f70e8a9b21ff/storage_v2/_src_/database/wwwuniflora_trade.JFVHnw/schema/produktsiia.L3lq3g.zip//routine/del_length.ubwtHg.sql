create function del_length()
  returns trigger
language plpgsql
as $$
BEGIN

delete from "продукция"."продукция"  where "код_детализации"=old.id and "код_структуры"=6;

RETURN OLD;
END;
$$;

