create function upd_pass_before_after_update()
  returns trigger
language plpgsql
as $$
BEGIN

NEW.пароль=md5(NEW.пароль) where id=old.id;

RETURN NEW;
END;
$$;

