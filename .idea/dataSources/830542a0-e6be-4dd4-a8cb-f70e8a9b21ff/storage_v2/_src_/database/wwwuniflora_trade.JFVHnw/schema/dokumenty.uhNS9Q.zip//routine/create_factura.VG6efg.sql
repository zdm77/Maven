create function create_factura()
  returns trigger
language plpgsql
as $$
begin
  INSERT INTO "документы"."фактуры"("код_закупки", "дата_фактуры",
   "код_пользователя", "код_статуса")
  VALUES (new.id, new.дата_закупки, new.код_пользователя,
   1);
RETURN NEW;

END;
$$;

