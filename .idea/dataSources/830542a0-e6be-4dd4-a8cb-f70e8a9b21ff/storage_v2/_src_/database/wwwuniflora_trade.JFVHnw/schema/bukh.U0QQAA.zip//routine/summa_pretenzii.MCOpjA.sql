create function "сумма_претензий"("i_код_плантации" integer, i_arch_pr integer DEFAULT 0)
  returns numeric
language plpgsql
as $$
declare

  l_pret numeric;
  l_sum_pret numeric;
  l_sum_odobr numeric;
  l_stat varchar;
  l_id integer;

BEGIN
  l_pret=0;
  FOR l_sum_pret, l_sum_odobr, l_stat IN
  SELECT COALESCE(a."сумма_притензии", 0),
         COALESCE(a."одобренная_сумма_притензии", 0),
         a."статус_притензии"
  from "бух".sub_awb_detail a
       inner join "бух".sub_awb sa on (sa.id = a."код_sub_awb")
       inner join "бух".awb aw on (aw.id = sa."код_AWB")
  where "код_плантации" = i_код_плантации and aw."архив_awb"=i_arch_pr
  LOOP
    if l_stat = 'ok' THEN
      l_pret=l_pret+l_sum_odobr ;
      else
      l_pret=l_pret+l_sum_pret ;

    END IF;
  END LOOP;
  RETURN l_pret;

END;
$$;

