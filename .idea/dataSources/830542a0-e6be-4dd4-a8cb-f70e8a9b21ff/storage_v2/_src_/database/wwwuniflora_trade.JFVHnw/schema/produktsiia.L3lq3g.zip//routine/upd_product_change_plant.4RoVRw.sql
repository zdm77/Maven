create function upd_product_change_plant()
  returns trigger
language plpgsql
as $$
BEGIN
  update "продукция"."продукция"
  set name = new . name,
      uni_name = new . name,
      reg_name = new . name
  where код_детализации = old . id and
        код_структуры = 4;
 
  RETURN NEW;
END;
$$;

