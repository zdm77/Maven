create function del_all_zakupka()
  returns integer
language plpgsql
as $$
declare i integer;
BEGIN
delete from "документы"."фактура_деталь";
SELECT setval('документы.фактура_деталь_id_seq',1) into i;
delete from "документы"."фактуры";
SELECT setval('документы.фактуры_id_seq',1) into i;
delete from "документы"."закупки_деталь";
SELECT setval('документы.закупки_деталь_id_seq',1) into i;
delete from "документы"."закупки";
SELECT setval('документы.закупки_id_seq',1) into i;
return i;
END;
$$;

