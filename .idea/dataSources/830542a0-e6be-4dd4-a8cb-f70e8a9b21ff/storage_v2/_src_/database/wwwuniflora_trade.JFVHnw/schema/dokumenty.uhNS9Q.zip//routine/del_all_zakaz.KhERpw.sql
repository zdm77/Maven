create function del_all_zakaz()
  returns integer
language plpgsql
as $$
DECLARE
 i integer;
BEGIN
delete from "документы"."заказы";
SELECT setval('документы.заказы_id_seq',1) into i;
SELECT setval('документы.заказы_деталь_id_seq',1) into i;
delete from "стендинг"."стендинг";
SELECT setval('стендинг.стендинг_id_seq',1) into i;
delete from "маркировки"."запрет_плантаций";
SELECT setval('маркировки.запрет_плантаций_id_seq',1) into i;
delete from "маркировки"."желаемые_плантации";
SELECT setval('маркировки.желаемые_плантации_id_seq',1) into i;
update "маркировки"."маркировки"  set "желаемые_плантации"=NULL, "запрет_плантаций"=null;
return i;
END;
$$;

